import Foundation
import SwiftUI


/*
 What are Enum Raw Values?
 Sometimes you need to assign concrete underlying values (like Integers or Strings) directly to your enum cases so they have real-world meaning and can be converted back and forth dynamically.

 By default, if you specify that an enum stores integers, Swift automatically numbers your cases starting from 0:

 Sometimes you need to be able to assign values to enums so they have meaning. This lets you create them dynamically, and also use them in different ways.

 For example, you might create a Planet enum that stores integer values for each of its cases:

 */

// Swift automatically assigns 0 to mercury, 1 to venus, 2 to earth, etc.
enum Planet: Int {
    case mercury
    case venus
    case earth
    case mars
}

// You can recreate an enum instance directly from its raw integer value!
let earth = Planet(rawValue: 2)
// earth becomes Planet.earth because it sits at index 2

/*

 Customizing Starting Values
 You don't have to start at 0. If you assign a specific value to the first case, Swift will automatically count upwards from there:

 */
enum Planet: Int {
    case mercury = 1
    case venus
    case earth    // Automatically becomes 2
    case mars     // Automatically becomes 3
}

let thirdPlanet = Planet(rawValue: 3) // This is Planet.mars!

/*
 Real-World iOS Example: API Status Codes or Database Identifiers
 In iOS development, raw values are heavily used when communicating with servers or local databases that send integer or string codes (like HTTP status codes or database row IDs) which your app needs to safely map back into type-safe enums:
 */

enum NetworkError: Int {
    case unauthorized = 401
    case notFound = 404
    case serverError = 500
}

// Converting a raw integer code received from an API response into our type-safe enum
let errorCode = NetworkError(rawValue: 404)
// Returns NetworkError.notFound

/*
 Here is your complete, fully commented, two-cell real-world iOS app example! It pulls together everything we've built so far—and introduces Enum Raw Values to tie underlying integer codes directly to our app enums (like mapping database rows or error codes).

 Imagine our Flight Dashboard App, where raw values allow us to map underlying integer database codes directly into our seating classes and error handling states!

 Cell 1: The Backend Swift Logic & Data State
 This cell manages our app state, utilizing constants, variables, primitives, collections, standard enums, associated-value enums, and now enums with raw values.
 */

// =====================================================================
// BACKEND SWIFT LOGIC & STATE (Flight Dashboard App)
// =====================================================================

import Foundation

// 1. STANDARD ENUMERATIONS: Fixed choices
enum AppTheme {
    case light
    case dark
    case systemDefault
}

// 2. ENUMS WITH RAW VALUES: Assigning underlying Integer values to cases
// Swift automatically assigns 1 to economy, 2 to business, and 3 to firstClass
enum SeatClass: Int {
    case economy = 1
    case business = 2
    case firstClass = 3
}

// 3. ENUMS WITH ASSOCIATED VALUES: Carrying custom dynamic payloads
enum FlightActivity {
    case waiting(gateNumber: String)
    case boarding(boardingGroup: Int)
    case delayed(reason: String, delayMinutes: Int)
}

class FlightDashboardViewModel {

    // 4. CONSTANTS (let): Fixed app rules and static metadata
    let airlineName: String = "SwiftAir Global"
    let flightNumber: String = "SW-2026"

    // 5. VARIABLES & PRIMITIVE TYPES (var): Dynamic state updates
    var passengerName: String = "Navjot"
    var seatNumber: Int = 14
    var ticketPrice: Double = 299.99
    var isBoardingPassActive: Bool = true

    // 6. USING ENUMS FOR STATE
    var currentTheme: AppTheme = .dark

    // Initializing our Raw Value enum using an integer lookup (e.g., loaded from a database row or user profile)
    var selectedSeatClass: SeatClass = SeatClass(rawValue: 2) ?? .economy // Defaults to economy if rawValue is invalid

    var currentFlightActivity: FlightActivity = .delayed(reason: "Air Traffic Control", delayMinutes: 30)

    // 7. COLLECTIONS (Arrays, Sets, Dictionaries, & Empty Collections)
    var gateStops: [String] = [String]()                 // Empty Array
    var loyaltyPerks: Set<String> = Set<String>()          // Empty Set
    var seatPreferences: [String: String] = [String: String]() // Empty Dictionary

    // 8. BACKEND FUNCTION: Simulates check-in and updates state
    func performCheckIn() {
        // Toggles boolean pass state
        isBoardingPassActive.toggle()

        // Updates associated-value enum
        currentFlightActivity = .boarding(boardingGroup: 2)
        currentTheme = .light

        // Changing seat class dynamically via a raw integer lookup (e.g. user upgrades to First Class = 3)
        if let upgradedClass = SeatClass(rawValue: 3) {
            selectedSeatClass = upgradedClass
        }

        // Populating collections
        gateStops.append("Security Check")
        gateStops.append("Gate B4 Boarding")

        loyaltyPerks.insert("Lounge Access")
        loyaltyPerks.insert("Priority Boarding")

        seatPreferences["mealType"] = "Vegetarian"
        seatPreferences["seatingPreference"] = "Window Seat"
    }
}

// =====================================================================
// ACTUAL UI SCREEN CODE (SwiftUI Interface)
// =====================================================================

import SwiftUI

struct FlightDashboardView: View {

    // Connects our backend view model logic to this SwiftUI screen
    @State private var viewModel = FlightDashboardViewModel()

    var body: some View {
        VStack(spacing: 14) {

            // --- HEADER SECTION ---
            Text("Welcome to \(viewModel.airlineName)")
                .font(.title2)
                .bold()

            // --- ASSOCIATED-VALUE ENUM DISPLAY SECTION ---
            HStack {
                Text("Flight: \(viewModel.flightNumber)")
                Spacer()

                Group {
                    switch viewModel.currentFlightActivity {
                    case .waiting(let gate):
                        Text("Waiting at Gate \(gate)")
                    case .boarding(let group):
                        Text("Boarding Group \(group)")
                            .foregroundColor(.green)
                    case .delayed(let reason, let minutes):
                        Text("Delayed (\(reason)): \(minutes) mins")
                            .foregroundColor(.red)
                    }
                }
                .font(.subheadline)
                .bold()
            }
            .padding(.horizontal)

            // --- PASSENGER & RAW VALUE ENUM SECTION ---
            VStack(alignment: .leading, spacing: 4) {
                Text("Passenger: \(viewModel.passengerName)")

                // Displaying both the Enum case and its underlying Raw Value integer!
                Text("Seat Class: \(viewModel.selectedSeatClass) (Raw Code: \(viewModel.selectedSeatClass.rawValue))")
                    .foregroundColor(.blue)

                Text("Active Theme Mode: \(viewModel.currentTheme)")
                Text("Pass Active: \(viewModel.isBoardingPassActive)")
                    .foregroundColor(viewModel.isBoardingPassActive ? .green : .red)
            }
            .padding()
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.gray.opacity(0.1))
            .cornerRadius(8)

            // --- POPULATED COLLECTIONS SECTION ---
            VStack(alignment: .leading, spacing: 2) {
                Text("Gate Sequence (Array):")
                    .font(.caption)
                    .bold()
                Text("\(viewModel.gateStops)")
                    .font(.caption2)
            }
            .frame(maxWidth: .infinity, alignment: .leading)

            VStack(alignment: .leading, spacing: 2) {
                Text("Unique Loyalty Perks (Set):")
                    .font(.caption)
                    .bold()
                Text("\(viewModel.loyaltyPerks)")
                    .font(.caption2)
                    .foregroundColor(.purple)
            }
            .frame(maxWidth: .infinity, alignment: .leading)

            VStack(alignment: .leading, spacing: 2) {
                Text("Passenger Preferences (Dictionary):")
                    .font(.caption)
                    .bold()
                Text("Meal: \(viewModel.seatPreferences["mealType"] ?? "None") | Spot: \(viewModel.seatPreferences["seatingPreference"] ?? "Any")")
                    .font(.caption2)
                    .foregroundColor(.orange)
            }
            .frame(maxWidth: .infinity, alignment: .leading)

            // --- INTERACTIVE BUTTON SECTION ---
            Button(action: {
                viewModel.performCheckIn()
            }) {
                Text("Check-In & Upgrade Seat (Raw Value)")
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
        }
        .padding()
    }
}
