import Foundation

/*
 Explanation:

 In Swift, Doubles are used for numbers that contain fractional or decimal values (like 3.141 or 38.5), whereas Integers only handle whole numbers. Swift automatically infers the Double type whenever you include a decimal point.

 Booleans (Bool) represent simple binary logic: they can only be either true or false. Just like with numbers, Swift automatically understands a variable is a Boolean when you assign a true/false value to it.

 */

// 1. Working with Doubles (decimal numbers)
var pi = 3.141
var score = 98.5

// You can update a Double as long as the new value also has a decimal/floating-point format
score = 99.9

// 2. Working with Booleans (true/false states)
var awesome = true
var isGameOver = false

// You can toggle booleans easily when state changes
isGameOver.toggle() // isGameOver becomes true now!

// 3. Printing out the results
print("Pi is: \(pi)")
print("Current score is: \(score)")
print("Is it awesome? \(awesome)")
print("Is the game over? \(isGameOver)")

