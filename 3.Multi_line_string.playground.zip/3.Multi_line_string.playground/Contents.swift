import Foundation

/*

 Moving right along on Multi-line strings! Standard Swift strings use single double quotes, but they don't allow line breaks directly.

 When you need a string that spans multiple lines, Swift uses three double quote marks (""").

 Here are the two best ways to use multi-line strings in Swift:

 1. Actual Multi-Line String (Preserving Line Breaks)
 If you want the actual output text to span across multiple lines, put your content inside triple quotes:

 */

// The opening and closing triple quotes MUST be on their own separate lines
var str1 = """
This goes
over multiple
lines
"""

print(str1)
/*
 Output:
 This goes
 over multiple
 lines
 */

/*

 2. Neat Code Multi-Line String (Ignoring Line Breaks)
 If you want to split a long string across multiple lines in your code just to keep it tidy, but you want the actual resulting text to stay on one single line, end each line with a backslash (\):

 */

var str2 = """
This goes \
over multiple \
lines
"""

print(str2)
// Output: This goes over multiple lines
