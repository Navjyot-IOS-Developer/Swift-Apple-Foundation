import Foundation
import SwiftUI

/*
 What are Arithmetic Operators?
 Now that you know all the basic data types in Swift (like Int and Double), we can start performing math on them using operators—the standard symbols like +, -, *, and /.

 Here are a couple of test variables to work with:
 */

let firstScore = 12
let secondScore = 4

// Addition (+)
let total = firstScore + secondScore // 16

// Subtraction (-)
let difference = firstScore - secondScore // 8

// Multiplication (*)
let product = firstScore * secondScore // 48

// Division (/)
let divided = firstScore / secondScore // 3

/*
 2. The Remainder Operator (%)Swift has a special operator called the remainder operator (sometimes called modulo), represented by the percent sign (%). It calculates how many times one number fits inside another and returns whatever value is left over.For example, if secondScore is 4, dividing 13 by 4 fits three times ($4 \times 3 = 12$), leaving a remainder of 1:
 */

let remainder = 13 % secondScore
// Output: 1

/*
 Real-World iOS Example: Calculating Cart Totals & Item Grouping
 In mobile app development, arithmetic operators are used everywhere—from calculating final checkout totals (subtotal + tax) to determining if items fit evenly into grid layouts or pagination pages using remainder operators:

 */
// Calculating total price for an online store cart
let itemPrice: Double = 19.99
let quantity: Double = 3.0
let shippingFee: Double = 5.00

// Using multiplication and addition operators
let subtotal = itemPrice * quantity
let finalOrderTotal = subtotal + shippingFee
// finalOrderTotal evaluates to 64.97


