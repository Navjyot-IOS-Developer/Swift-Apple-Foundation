import Foundation
import SwiftUI

/*

 What are Enum Associated Values?
 As well as storing a simple value, enums can also store associated values attached to each case. This lets you attach additional information to your enums so they can represent more nuanced data.

 For example, we might define an enum that stores various kinds of activities:

 That lets us say that someone is talking, but we don’t know what they are talking about, or we can know that someone is running, but we don’t know where they are running to.

 Enum associated values let us add those additional details:

 What are Enum Associated Values?
 While standard enums let you group clean, fixed choices together (like .onTime or .dark), sometimes you need to attach extra, custom data directly to a specific case.

 Think of it like a train ticket status: knowing it's "delayed" is useful, but knowing it's delayed by 45 minutes makes the data actually actionable. Associated values let you attach custom data types (like an Int or a String) right inside an enum case!

 */

enum Activity {
    case bored
    case running
    case talking
    case singing
}

enum Activity {
    case bored
    case running(destination: String)
    case talking(topic: String)
    case singing(volume: Int)
}

let talking = Activity.talking(topic: "football")

// 1. Defining an enum with associated values
enum FlightTask {
    case checkIn(passengerName: String)
    case bookSeat(seatNumber: Int)
    case updateStatus(statusMessage: String, delayMinutes: Int)
}

// 2. Creating instances with custom data attached
let currentTask = FlightTask.updateStatus(statusMessage: "Gate Change", delayMinutes: 20)

/*
 Real-World iOS Example: Complex App Notifications or Network Responses
 In mobile development, associated values are incredible for handling asynchronous states—like when a network request either fails with a specific error message or succeeds with user data:

 */

// Defining an API result enum that carries custom payload data per case
enum NetworkResponse {
    case success(responseData: String)
    case failure(errorCode: Int, errorMessage: String)
}

// Using the success case and attaching a custom string payload
letserverResponse = NetworkResponse.success(responseData: "User profile loaded successfully.")


/*
 ere is your complete, fully commented, two-cell real-world iOS app example! It pulls together everything we've built so far—and introduces Enum Associated Values to attach custom data payload strings or integers directly to our flight tracking and booking states.

 Imagine our Flight Dashboard App, where associated values let us track specific details like gate numbers, delay lengths, or dynamic error messages right inside our enums!

 Cell 1: The Backend Swift Logic & Data State
 This cell manages our app state, utilizing constants, variables, primitives, collections, standard enums, and now enums with associated values.

 */

// =====================================================================
// BACKEND SWIFT LOGIC & STATE (Flight Dashboard App)
// =====================================================================

import Foundation

// 1. STANDARD ENUMERATIONS (enum): Fixed choices with no extra data attached
enum AppTheme {
    case light
    case dark
    case systemDefault
}

enum SeatClass {
    case economy
    case business
    case firstClass
}

// 2. ENUMS WITH ASSOCIATED VALUES: Enums that can carry custom data payloads per case
enum FlightActivity {
    case waiting(gateNumber: String)
    case boarding(boardingGroup: Int)
    case delayed(reason: String, delayMinutes: Int)
}

class FlightDashboardViewModel {

    // 3. CONSTANTS (let): Fixed app rules and static metadata
    let airlineName: String = "SwiftAir Global"
    let flightNumber: String = "SW-2026"

    // 4. VARIABLES & PRIMITIVE TYPES (var): Dynamic state that updates based on user actions
    var passengerName: String = "Navjot"
    var seatNumber: Int = 14
    var ticketPrice: Double = 299.99
    var isBoardingPassActive: Bool = true

    // 5. USING ENUMS FOR STATE: Type-safe variables
    var currentTheme: AppTheme = .dark
    var selectedSeatClass: SeatClass = .economy

    // 6. USING AN ENUM WITH ASSOCIATED VALUES: Carrying a custom delay reason and minute count!
    var currentFlightActivity: FlightActivity = .delayed(reason: "Air Traffic Control", delayMinutes: 30)

    // 7. COLLECTIONS (Arrays, Sets, Dictionaries, & Empty Collections)
    var gateStops: [String] = [String]()                 // Empty Array for sequential stops
    var loyaltyPerks: Set<String> = Set<String>()          // Empty Set for unique perks
    var seatPreferences: [String: String] = [String: String]() // Empty Dictionary for configurations

    // 8. BACKEND FUNCTION: Simulates user check-in, updating associated values and populating collections
    func performCheckIn() {
        // Toggles boolean pass state
        isBoardingPassActive.toggle()

        // Updates our associated-value enum with a new case and a fresh custom data payload
        currentFlightActivity = .boarding(boardingGroup: 2)
        currentTheme = .light

        // Populating our collections
        gateStops.append("Security Check")
        gateStops.append("Gate B4 Boarding")

        loyaltyPerks.insert("Lounge Access")
        loyaltyPerks.insert("Priority Boarding")

        seatPreferences["mealType"] = "Vegetarian"
        seatPreferences["seatingPreference"] = "Window Seat"
    }
}

// =====================================================================
// ACTUAL UI SCREEN CODE (SwiftUI Interface)
// =====================================================================

import SwiftUI

struct FlightDashboardView: View {

    // Connects our backend view model logic to this SwiftUI screen
    @State private var viewModel = FlightDashboardViewModel()

    var body: some View {
        VStack(spacing: 14) {

            // --- HEADER SECTION ---
            Text("Welcome to \(viewModel.airlineName)")
                .font(.title2)
                .bold()

            // --- ASSOCIATED-VALUE ENUM DISPLAY SECTION ---
            // Displays status information carrying custom dynamic payloads
            HStack {
                Text("Flight: \(viewModel.flightNumber)")
                Spacer()

                // Using a switch statement to safely read the associated values inside our enum
                Group {
                    switch viewModel.currentFlightActivity {
                    case .waiting(let gate):
                        Text("Waiting at Gate \(gate)")
                    case .boarding(let group):
                        Text("Boarding Group \(group)")
                            .foregroundColor(.green)
                    case .delayed(let reason, let minutes):
                        Text("Delayed (\(reason)): \(minutes) mins")
                            .foregroundColor(.red)
                    }
                }
                .font(.subheadline)
                .bold()
            }
            .padding(.horizontal)

            // --- PASSENGER & THEME SECTION ---
            VStack(alignment: .leading, spacing: 4) {
                Text("Passenger: \(viewModel.passengerName)")
                Text("Seat Class: \(viewModel.selectedSeatClass)")
                Text("Active Theme Mode: \(viewModel.currentTheme)")
                Text("Pass Active: \(viewModel.isBoardingPassActive)")
                    .foregroundColor(viewModel.isBoardingPassActive ? .green : .red)
            }
            .padding()
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.gray.opacity(0.1))
            .cornerRadius(8)

            // --- POPULATED COLLECTIONS SECTION ---
            VStack(alignment: .leading, spacing: 2) {
                Text("Gate Sequence (Array):")
                    .font(.caption)
                    .bold()
                Text("\(viewModel.gateStops)")
                    .font(.caption2)
            }
            .frame(maxWidth: .infinity, alignment: .leading)

            VStack(alignment: .leading, spacing: 2) {
                Text("Unique Loyalty Perks (Set):")
                    .font(.caption)
                    .bold()
                Text("\(viewModel.loyaltyPerks)")
                    .font(.caption2)
                    .foregroundColor(.purple)
            }
            .frame(maxWidth: .infinity, alignment: .leading)

            VStack(alignment: .leading, spacing: 2) {
                Text("Passenger Preferences (Dictionary):")
                    .font(.caption)
                    .bold()
                Text("Meal: \(viewModel.seatPreferences["mealType"] ?? "None") | Spot: \(viewModel.seatPreferences["seatingPreference"] ?? "Any")")
                    .font(.caption2)
                    .foregroundColor(.orange)
            }
            .frame(maxWidth: .infinity, alignment: .leading)

            // --- INTERACTIVE BUTTON SECTION ---
            Button(action: {
                viewModel.performCheckIn()
            }) {
                Text("Check-In & Update Flight Activity")
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
        }
        .padding()
    }
}


