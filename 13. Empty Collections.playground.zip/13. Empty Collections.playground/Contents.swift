import Foundation
import SwiftUI

/*

 Now let's move on to Creating empty collections, picking up right where your tutorial left off!

 Sometimes you don't have all your data upfront when you start your app. Instead, you need to declare an empty collection and fill it up as the user interacts with your app.

 Here is how you create empty versions of all three collections in a single, clean code cell:
 Arrays, sets, and dictionaries are called collections, because they collect values together in one place.

 If you want to create an empty collection just write its type followed by opening and closing parentheses. For example, we can create an empty dictionary with strings for keys and values like this:


 */
// 1. Creating an empty Dictionary (keys and values are Strings)
var teams = [String: String]()
teams["Paul"] = "Red" // Adding an entry later

// 2. Creating an empty Array (to store Integers)
var results = [Int]()
results.append(42) // Adding an item later

// 3. Creating an empty Set (to store Strings)
// Note: Sets use a special angle-bracket syntax because they don't use square brackets to initialize!
var words = Set<String>()
words.insert("Swift") // Adding an item later

/*
 Here is your complete, fully commented, two-cell real-world iOS app example! It incorporates everything we've learned so far—including our brand-new concept: Empty Collections instantiated at launch and populated dynamically as the user interacts with the app.

 Imagine an In-Flight Flight & Passenger Management Dashboard where collections start completely empty when the app boots up and fill up as the passenger interacts with the screen.

 Cell 1: The Backend Swift Logic & Data State
 This cell manages our app state, utilizing constants, variables, primitives, arrays, sets, tuples, dictionaries, and empty collections ready to be populated.
 */

// =====================================================================
// BACKEND SWIFT LOGIC & STATE (Flight Dashboard App)
// =====================================================================

import Foundation

class FlightDashboardViewModel {

    // 1. CONSTANTS (let): Fixed app rules and static flight metadata
    let airlineName: String = "SwiftAir Global"
    let flightNumber: String = "SW-2026"

    // 2. VARIABLES & PRIMITIVE TYPES (var): Dynamic state that updates based on user actions
    var passengerName: String = "Navjot"
    var seatNumber: Int = 14
    var ticketPrice: Double = 299.99
    var isBoardingPassActive: Bool = true

    // 3. EMPTY COLLECTIONS: Initialized empty at app launch, ready to be filled dynamically
    var gateStops: [String] = [String]()                 // Empty Array for sequential stops
    var loyaltyPerks: Set<String> = Set<String>()          // Empty Set for unique perks (no duplicates)
    var seatPreferences: [String: String] = [String: String]() // Empty Dictionary for configurations

    // 4. TUPLES ((String, Int)): Fixed-size groupings for tightly coupled return values
    var flightStatus: (statusMessage: String, gateDelayMinutes: Int) = (statusMessage: "On Time", gateDelayMinutes: 0)

    // 5. BACKEND FUNCTION: Simulates user interaction, populating our empty collections and mutating state
    func checkInAndPopulateData() {
        // Toggles boolean pass state
        isBoardingPassActive.toggle()

        // Populating our previously empty Array with sequential steps
        gateStops.append("Security Check")
        gateStops.append("Customs & Immigration")
        gateStops.append("Gate B4 Boarding")

        // Populating our previously empty Set with perks (adding a duplicate to test automatic filtering)
        loyaltyPerks.insert("Lounge Access")
        loyaltyPerks.insert("Priority Boarding")
        loyaltyPerks.insert("Lounge Access") // Duplicate! The Set will automatically ignore this.

        // Populating our previously empty Dictionary with key-value preference lookups
        seatPreferences["mealType"] = "Vegetarian"
        seatPreferences["seatingPreference"] = "Window Seat"
        seatPreferences["baggageSize"] = "Carry-On Only"

        // Updates flight status tuple
        flightStatus = (statusMessage: "Boarding Now", gateDelayMinutes: 0)
    }
}

// =====================================================================
// ACTUAL UI SCREEN CODE (SwiftUI Interface)
// =====================================================================

import SwiftUI

struct FlightDashboardView: View {

    // Connects our backend view model logic to this SwiftUI screen
    @State private var viewModel = FlightDashboardViewModel()

    var body: some View {
        VStack(spacing: 14) {

            // --- HEADER SECTION ---
            // Displays static brand data using constants and string interpolation
            Text("Welcome to \(viewModel.airlineName)")
                .font(.title2)
                .bold()

            // --- TUPLE DISPLAY SECTION ---
            // Accesses nested tuple elements via dot notation
            HStack {
                Text("Flight: \(viewModel.flightNumber)")
                Spacer()
                Text("Status: \(viewModel.flightStatus.statusMessage)")
                    .foregroundColor(.green)
                    .bold()
            }
            .padding(.horizontal)

            // --- PASSENGER & PRIMITIVE TYPES SECTION ---
            // Displays strings, integers, doubles, and booleans
            VStack(alignment: .leading, spacing: 4) {
                Text("Passenger: \(viewModel.passengerName)")
                Text("Seat: Row \(viewModel.seatNumber)")
                Text("Price: $\(viewModel.ticketPrice)")
                Text("Pass Active: \(viewModel.isBoardingPassActive)")
                    .foregroundColor(viewModel.isBoardingPassActive ? .blue : .red)
            }
            .padding()
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.gray.opacity(0.1))
            .cornerRadius(8)

            // --- ARRAY DISPLAY SECTION (Populated from Empty) ---
            VStack(alignment: .leading, spacing: 2) {
                Text("Gate Sequence (Array):")
                    .font(.caption)
                    .bold()
                Text("\(viewModel.gateStops)")
                    .font(.caption2)
            }
            .frame(maxWidth: .infinity, alignment: .leading)

            // --- SET DISPLAY SECTION (Populated from Empty) ---
            VStack(alignment: .leading, spacing: 2) {
                Text("Unique Loyalty Perks (Set - Duplicates Filtered):")
                    .font(.caption)
                    .bold()
                Text("\(viewModel.loyaltyPerks)")
                    .font(.caption2)
                    .foregroundColor(.purple)
            }
            .frame(maxWidth: .infinity, alignment: .leading)

            // --- DICTIONARY DISPLAY SECTION (Populated from Empty) ---
            VStack(alignment: .leading, spacing: 2) {
                Text("Passenger Preferences (Dictionary):")
                    .font(.caption)
                    .bold()
                Text("Meal: \(viewModel.seatPreferences["mealType"] ?? "None") | Spot: \(viewModel.seatPreferences["seatingPreference"] ?? "Any")")
                    .font(.caption2)
                    .foregroundColor(.orange)
            }
            .frame(maxWidth: .infinity, alignment: .leading)

            // --- INTERACTIVE BUTTON SECTION ---
            // Tapping this triggers the backend function, populating empty collections and updating the UI instantly
            Button(action: {
                viewModel.checkInAndPopulateData()
            }) {
                Text("Complete Check-In & Populate App Data")
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
        }
        .padding()
    }
}
