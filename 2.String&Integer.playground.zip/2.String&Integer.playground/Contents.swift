import Foundation

//var greeting = "Hello, playground"

/*
 Now that you've got the basics of variables down, let's look at the two most common types of data you'll work with in Swift: Strings (text) and Integers (whole numbers), which you can explore further on Strings and integers.

 Swift is a type-safe language. This means every variable has to be of one specific data type, and Swift figures out what that type is based on the value you give it.

 Here is how Strings and Integers work in practice:

 Important Rule: Types Don't Mix
 Because Swift is type-safe, you cannot accidentally mix them up. For example, once Swift knows greeting is a String, you cannot do this:
 */

// 1. A String variable (text enclosed in double quotes)
var greeting = "Hello, playground"
greeting = "Goodbye" // This is allowed because it's still a String!

// 2. An Integer variable (whole numbers)
var age = 38

// 3. Large numbers with underscores for readability
// Swift ignores the underscores, making long numbers much easier to read for humans
var population = 8_000_000

greeting = 38 // ❌ Error! You can't assign an Integer to a String variable.
