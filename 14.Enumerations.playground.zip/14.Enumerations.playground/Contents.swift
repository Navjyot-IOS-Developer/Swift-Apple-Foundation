import Foundation
import SwiftUI

/*
 Good afternoon! Let's dive right into Enumerations (usually called enums), picking up right from your Enumerations tutorial page!

 What is an Enum?
 An Enumeration is a way of defining a group of related values under a single custom type, making your code much cleaner, safer, and easier to read.

 Imagine you are writing code to track whether a network request or task succeeded or failed. Without enums, you might represent this using plain strings:

 */

let result = "failure"

/*
 The problem? If someone accidentally misspells it later (let result2 = "failed" or let result3 = "fail"), Swift treats them as three completely different strings, leading to bugs!
 */

/// 1. Creating and Using Enums
//With an enum, you can define a strict Result type with fixed // cases so typos are impossible:

// 1. Define the enum
enum Result {
    case success
    case failure
}

// 2. Use one of the explicit cases
let currentResult = Result.failure

// Swift won't let you use random strings like "fail" or "failed" anymore!

/*Real-World iOS Example: App Theme Modes
In iOS development, enums are heavily used for states that have a fixed, finite set of options—like choosing an app's appearance mode:*/

// Defining an enum for UI themes
enum ThemeMode {
    case light
    case dark
    case systemDefault
}

// Using the enum in our app state
var activeTheme: ThemeMode = .dark

/*
 Here is your complete, fully commented, two-cell real-world iOS app example! It incorporates everything we've learned so far—including our brand-new concept: Enumerations (enum) to strictly manage app themes, flight statuses, and user booking states without risking string typos.

 Imagine our Flight Dashboard App, where enums cleanly handle our UI theme, user check-in status, and seat classes.

 Cell 1: The Backend Swift Logic & Data State
 This cell manages our app state, utilizing constants, variables, primitives, arrays, sets, tuples, dictionaries, empty collections, and now Enums.

 */

// =====================================================================
// BACKEND SWIFT LOGIC & STATE (Flight Dashboard App)
// =====================================================================

import Foundation

// 1. ENUMERATIONS (enum): Defining strict, related groups of values to eliminate typos
enum FlightStatus {
    case onTime
    case delayed
    case boardingNow
    case cancelled
}

enum AppTheme {
    case light
    case dark
    case systemDefault
}

enum SeatClass {
    case economy
    case business
    case firstClass
}

class FlightDashboardViewModel {

    // 2. CONSTANTS (let): Fixed app rules and static metadata
    let airlineName: String = "SwiftAir Global"
    let flightNumber: String = "SW-2026"

    // 3. VARIABLES & PRIMITIVE TYPES (var): Dynamic state that updates based on user actions
    var passengerName: String = "Navjot"
    var seatNumber: Int = 14
    var ticketPrice: Double = 299.99
    var isBoardingPassActive: Bool = true

    // 4. USING ENUMS FOR APP STATE: Type-safe variables instead of messy strings
    var currentTheme: AppTheme = .dark
    var flightState: FlightStatus = .onTime
    var selectedSeatClass: SeatClass = .economy

    // 5. COLLECTIONS (Arrays, Sets, Dictionaries, & Empty Collections)
    var gateStops: [String] = [String]()                 // Empty Array for sequential stops
    var loyaltyPerks: Set<String> = Set<String>()          // Empty Set for unique perks
    var seatPreferences: [String: String] = [String: String]() // Empty Dictionary for configurations

    // 6. BACKEND FUNCTION: Simulates user interaction, populating collections and updating enum states
    func performCheckIn() {
        // Toggles boolean pass state
        isBoardingPassActive.toggle()

        // Updates our state using strict Enums (no risk of typos like "boarding" vs "boarded")
        flightState = .boardingNow
        currentTheme = .light

        // Populating our collections
        gateStops.append("Security Check")
        gateStops.append("Gate B4 Boarding")

        loyaltyPerks.insert("Lounge Access")
        loyaltyPerks.insert("Priority Boarding")

        seatPreferences["mealType"] = "Vegetarian"
        seatPreferences["seatingPreference"] = "Window Seat"
    }
}

// =====================================================================
// ACTUAL UI SCREEN CODE (SwiftUI Interface)
// =====================================================================

import SwiftUI

struct FlightDashboardView: View {

    // Connects our backend view model logic to this SwiftUI screen
    @State private var viewModel = FlightDashboardViewModel()

    var body: some View {
        VStack(spacing: 14) {

            // --- HEADER SECTION ---
            Text("Welcome to \(viewModel.airlineName)")
                .font(.title2)
                .bold()

            // --- ENUM STATUS DISPLAY SECTION ---
            // Displays strict enum states safely on screen
            HStack {
                Text("Flight: \(viewModel.flightNumber)")
                Spacer()
                Text("Status: \(viewModel.flightState)") // Prints out enum case cleanly
                    .foregroundColor(.blue)
                    .bold()
            }
            .padding(.horizontal)

            // --- PASSENGER & THEME ENUM SECTION ---
            VStack(alignment: .leading, spacing: 4) {
                Text("Passenger: \(viewModel.passengerName)")
                Text("Seat Class: \(viewModel.selectedSeatClass)")
                Text("Active Theme Mode: \(viewModel.currentTheme)")
                Text("Pass Active: \(viewModel.isBoardingPassActive)")
                    .foregroundColor(viewModel.isBoardingPassActive ? .green : .red)
            }
            .padding()
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.gray.opacity(0.1))
            .cornerRadius(8)

            // --- POPULATED COLLECTIONS SECTION ---
            VStack(alignment: .leading, spacing: 2) {
                Text("Gate Sequence (Array):")
                    .font(.caption)
                    .bold()
                Text("\(viewModel.gateStops)")
                    .font(.caption2)
            }
            .frame(maxWidth: .infinity, alignment: .leading)

            VStack(alignment: .leading, spacing: 2) {
                Text("Unique Loyalty Perks (Set):")
                    .font(.caption)
                    .bold()
                Text("\(viewModel.loyaltyPerks)")
                    .font(.caption2)
                    .foregroundColor(.purple)
            }
            .frame(maxWidth: .infinity, alignment: .leading)

            VStack(alignment: .leading, spacing: 2) {
                Text("Passenger Preferences (Dictionary):")
                    .font(.caption)
                    .bold()
                Text("Meal: \(viewModel.seatPreferences["mealType"] ?? "None") | Spot: \(viewModel.seatPreferences["seatingPreference"] ?? "Any")")
                    .font(.caption2)
                    .foregroundColor(.orange)
            }
            .frame(maxWidth: .infinity, alignment: .leading)

            // --- INTERACTIVE BUTTON SECTION ---
            Button(action: {
                viewModel.performCheckIn()
            }) {
                Text("Check-In & Update App States")
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
        }
        .padding()
    }
}

