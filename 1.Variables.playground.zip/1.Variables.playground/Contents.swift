import Cocoa

var greeting = "Hello, playground"
var str = "swift program"


/*
 Based on the Variables tutorial you're looking at, think of a variable as a labeled storage box where you can keep data (like text, numbers, or true/false values) and change what's inside whenever you need to.

 Here is a simple, clear example of how variables work in Swift:

 Key Rules to Remember:
 var keyword: You only write var the very first time you create the variable.

 Updating values: When you want to change the value later (like currentScore = 100), you just use the variable name directly without var.

 Type Safety: Swift is a type-safe language. Once a variable is created as a specific data type (like an integer number or a string of text), Swift won't let you accidentally assign a completely different type to it later.

 */

// 1. Create a variable using the "var" keyword and give it an initial value
var currentScore = 0

// 2. Print or use the variable
print(currentScore) // Output: 0

// 3. Change ("vary") the value later on because it's a variable
currentScore = 100

print(currentScore) // Output: 100


