import Foundation

/*
 What is an Array?
 An Array is a collection of values stored together as a single item. Instead of creating separate variables for every single item, you can group them all inside a single array using square brackets ([]).

 1. Creating and Using Arrays
 Here is how you create an array in Swift, just like the example from your page:

 */
let john = "John Lennon"
let paul = "Paul McCartney"
let george = "George Harrison"
let ringo = "Ringo Starr"

// Grouping them into an array
let beatles = [john, paul, george, ringo]

print(beatles)
// Output: ["John Lennon", "Paul McCartney", "George Harrison", "Ringo Starr"]

/*
 2. Reading Values with Indexes
 Swift arrays are zero-indexed, meaning counting starts at 0. To read a specific item, put its position number inside square brackets:
 */

// This gets the first item ("John Lennon")
print(beatles[0])

// This gets the second item ("Paul McCartney")
print(beatles[1])

//------------Real UI and Backend logic swift code---------------

/*
 I completely follow you! You're asking how the foundational pieces we've learned so far—variables, constants, types, strings, numbers, and arrays—actually tie together to power the logic behind a real UI interaction in an iOS app.

 Imagine building a simple iOS app screen for a Quiz App or a Shopping Checkout Screen. When a user taps a button (like "Submit Answer" or "Add Item"), the backend Swift logic has to run behind the scenes: it reads data, performs logic checks using booleans and integers, updates variables, and compiles dynamic text using string interpolation to update the screen.

 Here is a complete, real-world style example in a single code cell showing how these concepts work together under the hood of an app UI event:
 */

// ==========================================
// BACKEND LOGIC FOR AN iOS APP INTERACTION
// ==========================================

// 1. Constants (Fixed app configuration or item details)
let maxAttempts: Int = 3
let itemName: String = "Swift Programming Guide"

// 2. Variables (State that changes based on user interaction)
var currentScore: Int = 85
var userAttemptCount: Int = 1
var isItemInCart: Bool = false
var itemPrice: Double = 14.99

// 3. Arrays (Collections of data shown in UI lists, like shopping history or past scores)
var recentScores: [Int] = [70, 75, 80, 85]

// ------------------------------------------
// SIMULATING A USER TAPPING A BUTTON IN THE UI
// ------------------------------------------

// User taps a "Toggle Cart" button
isItemInCart.toggle()

// User completes a level, updating our integer and array
currentScore += 10
recentScores.append(currentScore)

// Evaluating a boolean condition (Is the user allowed to try again?)
let canTryAgain: Bool = userAttemptCount < maxAttempts

// 4. String Interpolation (Generating the text to display right back on the UI screen)
let uiDisplayMessage = """
--- UI SCREEN UPDATE ---
Item: \(itemName)
In Cart: \(isItemInCart)
Price: $\(itemPrice)
New Score: \(currentScore)
Score History: \(recentScores)
Can Retry: \(canTryAgain)
"""

print(uiDisplayMessage)

/*
 Why this matters for iOS Development:
 Constants (let) keep your fixed configuration data secure.

 Variables (var) & Types (Int, Double, Bool) track the live state of your app (like user scores, toggles, and item counts).

 Arrays ([Int]) manage lists of data that populate table views or lists on your screen.

 String Interpolation (\()) stitches all that raw data together so your app can display clean, dynamic text to the user.
 */
