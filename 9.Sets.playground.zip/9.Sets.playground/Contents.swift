import Foundation

/*
 Sets are collections of values just like arrays, except they have two differences:

 Items aren’t stored in any order; they are stored in what is effectively a random order.
 No item can appear twice in a set; all items must be unique.

 What is a Set?
 At first glance, a Set looks a lot like an Array—it's a collection of values grouped together in square brackets. However, sets have two major differences that make them unique:

 Unordered: Items aren't stored in any specific order. Swift stores them in what is effectively a random (or unordered) sequence and makes no guarantees about their placement. Because of this, you cannot read values from a set using numerical indices (like mySet[0]) the way you do with arrays.

 Unique Items: No item can appear twice in a set. If you try to add a duplicate, Swift automatically ignores it!

 */
// 1. Creating a set from an array
let colors = Set(["red", "green", "blue"])

print(colors)
// Output might look like: ["green", "red", "blue"] (order is not guaranteed!)

// Passing an array with repeated items
let colors2 = Set(["red", "green", "blue", "red", "blue"])

print(colors2)
// The final set will only contain: "red", "green", and "blue" once each!

/*
 I certainly remember! We've built a solid foundation covering variables, constants, types (Strings, Integers, Doubles, Booleans), type annotations, arrays, and sets.

 To tie all of these together, let's look at a real-world iOS app scenario: an E-Commerce Checkout Screen or Wishlist Manager.

 In an online shopping app, you need constants for fixed store rules, variables and types for dynamic user actions, arrays to maintain an ordered list of recent items viewed, and a Set to guarantee that a user's favorite item IDs or unique promotional discount codes can never have duplicates.

 Here is a complete, single-cell example showing how all these concepts work in tandem under the hood of an iOS app:
 */

// ========================================================
// REAL-WORLD iOS APP LOGIC: E-COMMERCE WISHLIST & CART
// ========================================================

// 1. Constants (Fixed configuration data that never changes)
let storeName: String = "SwiftStyle Boutique"
let maxCartLimit: Int = 10

// 2. Variables, Numbers, Strings, and Booleans (Live app state)
var customerName: String = "Alex"
var cartItemCount: Int = 3
var itemPrice: Double = 49.99
var isUserLoggedIn: Bool = true

// 3. Arrays (Ordered lists, like recently viewed items shown in a carousel)
var recentlyViewedItems: [String] = ["Leather Wallet", "Wireless Earbuds", "Smart Watch"]

// 4. Sets (Unordered collections that guarantee unique values, like applied promo codes or unique favorite IDs)
// Notice how we intentionally added duplicate codes; the Set will automatically clean them up!
var appliedPromoCodes: Set<String> = Set(["WELCOME10", "FREESHIP", "WELCOME10", "SAVE20", "FREESHIP"])

// --------------------------------------------------------
// SIMULATING USER INTERACTION ON THE UI SCREEN
// --------------------------------------------------------

// User taps a button to add a new item to their viewed history
recentlyViewedItems.append("Running Shoes")

// User taps checkout; state updates
cartItemCount += 1
let subtotal: Double = Double(cartItemCount) * itemPrice

// --------------------------------------------------------
// GENERATING SCREEN DISPLAY TEXT USING STRING INTERPOLATION
// --------------------------------------------------------
let checkoutScreenSummary = """
========================================
WELCOME TO \(storeName.uppercased())
========================================
Customer: \(customerName) (Logged In: \(isUserLoggedIn))
Items in Cart: \(cartItemCount) (Max allowed: \(maxCartLimit))
Estimated Subtotal: $\(subtotal)

Recently Viewed Products (Array):
\(recentlyViewedItems)

Active Unique Promo Codes (Set - duplicates removed):
\(appliedPromoCodes)
========================================
"""

print(checkoutScreenSummary)

//---------------------Real time example UI and backend----

/*
 Here is how an iOS developer structures this! In modern iOS development, we separate the user interface (written in SwiftUI) from the underlying data and logic (written in standard Swift).

 Here are your two complete cells representing an actual UI screen and its backend logic working together to manage unique user discount codes (using a Set) and recently viewed items (using an Array):

 Cell 1: The Backend Swift Logic & Data State
 This cell handles all the data structures we've learned so far—constants, variables, arrays, and sets—managing the state behind the scenes.
 */

// ==========================================
// BACKEND SWIFT LOGIC & STATE
// ==========================================

import Foundation

class CheckoutViewModel {
    // 1. Constants (Fixed configuration)
    let storeName: String = "SwiftStyle Boutique"
    let maxCartLimit: Int = 10

    // 2. Variables & Primitive Types (Dynamic state)
    var customerName: String = "Alex"
    var cartItemCount: Int = 3
    var itemPrice: Double = 49.99
    var isUserLoggedIn: Bool = true

    // 3. Arrays (Ordered list of recently viewed items)
    var recentlyViewedItems: [String] = ["Leather Wallet", "Wireless Earbuds", "Smart Watch"]

    // 4. Sets (Unordered collection that automatically strips out duplicate promo codes)
    var appliedPromoCodes: Set<String> = Set(["WELCOME10", "FREESHIP", "WELCOME10", "SAVE20", "FREESHIP"])

    // Computed property for subtotal calculation
    var subtotal: Double {
        return Double(cartItemCount) * itemPrice
    }

    // Action function simulating user interaction
    func addNewItemToHistory(item: String) {
        recentlyViewedItems.append(item)
        cartItemCount += 1
    }
}

// ==========================================
// ACTUAL UI SCREEN CODE (SwiftUI)
// ==========================================

import SwiftUI

struct CheckoutScreenView: View {
    // Connects our backend view model logic to the UI
    @State private var viewModel = CheckoutViewModel()

    var body: some View {
        VStack(spacing: 20) {

            // Header Title using Constants & String Interpolation
            Text("Welcome to \(viewModel.storeName)")
                .font(.title)
                .bold()

            // User Status using Booleans & Strings
            Text("Customer: \(viewModel.customerName) (Logged In: \(viewModel.isUserLoggedIn))")
                .font(.subheadline)
                .foregroundColor(.secondary)

            // Cart Info using Integers & Doubles
            VStack(alignment: .leading, spacing: 5) {
                Text("Items in Cart: \(viewModel.cartItemCount) (Max: \(viewModel.maxCartLimit))")
                Text("Estimated Subtotal: $\(viewModel.subtotal)")
                    .bold()
            }
            .padding()
            .background(Color.gray.opacity(0.1))
            .cornerRadius(10)

            // Displaying Array Data (Recently Viewed List)
            VStack(alignment: .leading) {
                Text("Recently Viewed Products (Array):")
                    .bold()
                Text("\(viewModel.recentlyViewedItems)")
                    .font(.caption)
            }

            // Displaying Set Data (Unique Promo Codes - duplicates removed)
            VStack(alignment: .leading) {
                Text("Active Unique Promo Codes (Set):")
                    .bold()
                Text("\(viewModel.appliedPromoCodes)")
                    .font(.caption)
                    .foregroundColor(.green)
            }

            // UI Button simulating a user interaction
            Button(action: {
                // Triggers backend logic update when tapped
                viewModel.addNewItemToHistory(item: "Running Shoes")
            }) {
                Text("Add Viewed Item & Update Cart")
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
        }
        .padding()
    }
}
