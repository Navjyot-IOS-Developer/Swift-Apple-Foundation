import Foundation
import SwiftUI

/*

 What is Operator Overloading?
 Swift supports something called operator overloading, which is a fancy way of saying: what an arithmetic operator does depends entirely on the types of data you use it with.

 You are already used to the plus sign (+) adding numbers together, but Swift lets that same + sign do completely different jobs depending on the context:

 The Golden Rule: Swift is a strictly type-safe language. While operator overloading lets + work across numbers, strings, and arrays, Swift will never let you mix types (like trying to add an integer directly to a string, because code-wise, that doesn't make any sense!).

 Real-World iOS Example: Building an Itinerary Summary
 In mobile development, operator overloading is super handy when you want to merge separate travel itinerary arrays (like combining outbound flights with return flights) into a single master schedule:
 */

// =====================================================================
// BACKEND SWIFT LOGIC & STATE (Flight Dashboard App)
// =====================================================================

import Foundation

// 1. STANDARD ENUMERATIONS: Fixed choices
enum AppTheme {
    case light
    case dark
    case systemDefault
}

// 2. ENUMS WITH RAW VALUES: Assigning underlying integer codes
enum SeatClass: Int {
    case economy = 1
    case business = 2
    case firstClass = 3
}

// 3. ENUMS WITH ASSOCIATED VALUES: Carrying custom payloads
enum FlightActivity {
    case waiting(gateNumber: String)
    case boarding(boardingGroup: Int)
    case delayed(reason: String, delayMinutes: Int)
}

class FlightDashboardViewModel {

    // 4. CONSTANTS (let): Fixed app rules and static metadata
    let airlineName: String = "SwiftAir Global"
    let flightNumber: String = "SW-2026"

    // 5. VARIABLES & PRIMITIVE TYPES (var): Dynamic state updates
    var passengerName: String = "Navjot"
    var seatNumber: Int = 14
    var ticketPrice: Double = 299.99
    var isBoardingPassActive: Bool = true

    // 6. USING ENUMS FOR STATE
    var currentTheme: AppTheme = .dark
    var selectedSeatClass: SeatClass = SeatClass(rawValue: 2) ?? .economy
    var currentFlightActivity: FlightActivity = .delayed(reason: "Air Traffic Control", delayMinutes: 30)

    // 7. COLLECTIONS & OPERATOR OVERLOADING
    // We separate outbound and return legs so we can use the overloaded '+' operator to combine them!
    var outboundLegs: [String] = ["Delhi", "Dubai"]
    var returnLegs: [String] = ["London", "Delhi"]

    var gateStops: [String] = [String]()                 // Empty Array
    var loyaltyPerks: Set<String> = Set<String>()          // Empty Set
    var seatPreferences: [String: String] = [String: String]() // Empty Dictionary

    // 8. BACKEND FUNCTION: Simulates check-in and combines arrays using operator overloading
    func performCheckIn() {
        // Toggles boolean pass state
        isBoardingPassActive.toggle()

        // Updates associated-value enum
        currentFlightActivity = .boarding(boardingGroup: 2)
        currentTheme = .light

        // Upgrades seat class via raw value lookup
        if let upgradedClass = SeatClass(rawValue: 3) {
            selectedSeatClass = upgradedClass
        }

        // OPERATOR OVERLOADING (+): Combining two separate String arrays into a single master itinerary!
        gateStops = outboundLegs + returnLegs

        // Populating other collections
        loyaltyPerks.insert("Lounge Access")
        loyaltyPerks.insert("Priority Boarding")

        seatPreferences["mealType"] = "Vegetarian"
        seatPreferences["seatingPreference"] = "Window Seat"
    }
}

/*
 Why Operator Overloading is so neat:
 One Symbol, Multiple Jobs: The + sign adapts seamlessly depending on context—adding numbers, joining strings, or merging collections like arrays.

 Expressive Code: Writing outboundLegs + returnLegs reads like plain English while executing clean collection concatenation under the hood!
 */
