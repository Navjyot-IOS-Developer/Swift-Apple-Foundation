import Foundation
import SwiftUI

/*
 Swift has shorthand operators that combine one operator with an assignment, so you can change a variable in place. These look like the existing operators you know – +, -, *, and /, but they have an = on the end because they assign the result back to whatever variable you were using.

 For example, if someone scored 95 in an exam but needs to be penalized 5 points, you could write this:

 */

// 1. Start with an initial score variable
var score = 95

// 2. Use a compound assignment operator (-=) to subtract 5 in place
score -= 5

print(score)
// Output: 90

// 3. You can also use it with strings using (+=) to append text in place
var greeting = "Hello, "
greeting += "Navjot!"

print(greeting)
// Output: Hello, Navjot!

/*
Why it's useful:
Instead of writing out the full expression like score = score - 5, compound assignment operators (+=, -=, *=, /=) combine the math operation and the variable assignment into one clean, shorthand step!
*/
