import Foundation
import SwiftUI


/*
 What are Conditions?
 Now that you know how to use comparison operators to get a true or false result, you can use if statements to make your code make decisions! You give Swift a condition, and if that condition evaluates to true, it runs the block of code you provided.

 1. The Basic if Statement
 To check a condition, you write if, followed by your condition, followed by opening and closing braces ({ }):

 */

let firstCard = 11
let secondCard = 10

if firstCard + secondCard == 21 {
    print("Blackjack!")
}

/*
 2. Adding an else Clause
 If you want to provide alternative code to run when the condition is false, you can chain an else block right after:
 */

if firstCard + secondCard == 21 {
    print("Blackjack!")
} else {
    print("Regular cards")
}
/*

 3. Chaining Multiple Conditions with else if
 If you have more than two possible outcomes, you can check multiple conditions in sequence using else if:

 */

let firstCard = 1
let secondCard = 10

if firstCard + secondCard == 2 {
    print("Aces – lucky!")
} else if firstCard + secondCard == 21 {
    print("Blackjack!")
} else {
    print("Regular cards")
}

/*
 Here is your complete, fully commented, two-cell real-world iOS app example! It pulls together everything we've built so far—and integrates Conditions (if, else if, else) to dynamically evaluate passenger ticket pricing tiers and assign VIP boarding group privileges on the fly.

 Imagine our Flight Dashboard App, where conditions inspect data checks to automatically print console logs and configure custom UI badge statuses!

 Cell 1: The Backend Swift Logic & Data State
 This cell manages our app state, utilizing constants, variables, primitives, collections, enums, operator overloading, compound assignments, comparison operators, and now conditions.

 */

// =====================================================================
// BACKEND SWIFT LOGIC & STATE (Flight Dashboard App)
// =====================================================================

import Foundation

// 1. STANDARD ENUMERATIONS: Fixed choices
enum AppTheme {
    case light
    case dark
    case systemDefault
}

// 2. ENUMS WITH RAW VALUES: Assigning underlying integer codes
enum SeatClass: Int {
    case economy = 1
    case business = 2
    case firstClass = 3
}

// 3. ENUMS WITH ASSOCIATED VALUES: Carrying custom payloads
enum FlightActivity {
    case waiting(gateNumber: String)
    case boarding(boardingGroup: Int)
    case delayed(reason: String, delayMinutes: Int)
}

class FlightDashboardViewModel {

    // 4. CONSTANTS (let): Fixed app rules and static metadata
    let airlineName: String = "SwiftAir Global"
    let flightNumber: String = "SW-2026"
    let vipPriceThreshold: Double = 250.00

    // 5. VARIABLES & PRIMITIVE TYPES (var): Dynamic state updates
    var passengerName: String = "Navjot"
    var seatNumber: Int = 14
    var ticketPrice: Double = 299.99
    var isBoardingPassActive: Bool = true

    // 6. USING ENUMS FOR STATE
    var currentTheme: AppTheme = .dark
    var selectedSeatClass: SeatClass = SeatClass(rawValue: 2) ?? .economy
    var currentFlightActivity: FlightActivity = .delayed(reason: "Air Traffic Control", delayMinutes: 30)

    // 7. COLLECTIONS & OPERATOR OVERLOADING
    var outboundLegs: [String] = ["Delhi", "Dubai"]
    var returnLegs: [String] = ["London", "Delhi"]

    var gateStops: [String] = [String]()                 // Empty Array
    var loyaltyPerks: Set<String> = Set<String>()          // Empty Set
    var seatPreferences: [String: String] = [String: String]() // Empty Dictionary

    // 8. BACKEND FUNCTION: Uses CONDITIONS (if, else if, else) to make smart decision trees
    func performCheckIn() {
        // Toggles boolean pass state
        isBoardingPassActive.toggle()

        // Updates associated-value enum
        currentFlightActivity = .boarding(boardingGroup: 2)
        currentTheme = .light

        // Upgrades seat class via raw value lookup
        if let upgradedClass = SeatClass(rawValue: 3) {
            selectedSeatClass = upgradedClass
        }

        // Combining arrays using overloaded '+' operator
        gateStops = outboundLegs + returnLegs

        // POPULATING COLLECTIONS & APPLYING CONDITIONS
        loyaltyPerks.insert("Lounge Access")
        loyaltyPerks.insert("Priority Boarding")

        // CONDITIONS: Evaluating ticket price and seat number ranges to assign tier levels
        if ticketPrice >= 400.00 {
            seatPreferences["pricingTier"] = "Platinum VIP Tier"
            print("Console: Assigned Platinum VIP lounge access.")
        } else if ticketPrice >= vipPriceThreshold {
            seatPreferences["pricingTier"] = "Gold Tier"
            print("Console: Assigned standard priority boarding.")
        } else {
            seatPreferences["pricingTier"] = "Economy Tier"
            print("Console: Standard boarding process applies.")
        }

        seatPreferences["mealType"] = "Vegetarian"
        seatPreferences["seatingPreference"] = "Window Seat"
    }
}

// =====================================================================
// ACTUAL UI SCREEN CODE (SwiftUI Interface)
// =====================================================================

import SwiftUI

struct FlightDashboardView: View {

    // Connects our backend view model logic to this SwiftUI screen
    @State private var viewModel = FlightDashboardViewModel()

    var body: some View {
        VStack(spacing: 14) {

            // --- HEADER SECTION ---
            Text("Welcome to \(viewModel.airlineName)")
                .font(.title2)
                .bold()

            // --- ASSOCIATED-VALUE ENUM DISPLAY SECTION ---
            HStack {
                Text("Flight: \(viewModel.flightNumber)")
                Spacer()

                Group {
                    switch viewModel.currentFlightActivity {
                    case .waiting(let gate):
                        Text("Waiting at Gate \(gate)")
                    case .boarding(let group):
                        Text("Boarding Group \(group)")
                            .foregroundColor(.green)
                    case .delayed(let reason, let minutes):
                        Text("Delayed (\(reason)): \(minutes) mins")
                            .foregroundColor(.red)
                    }
                }
                .font(.subheadline)
                .bold()
            }
            .padding(.horizontal)

            // --- PASSENGER & CONDITION-DRIVEN TIER SECTION ---
            VStack(alignment: .leading, spacing: 4) {
                Text("Passenger: \(viewModel.passengerName)")
                Text("Seat Class: \(viewModel.selectedSeatClass) (Raw Code: \(viewModel.selectedSeatClass.rawValue))")
                    .foregroundColor(.blue)

                // Displays conditionally evaluated pricing tier dynamically
                Text("Pricing Tier: \(viewModel.seatPreferences["pricingTier"] ?? "Not Evaluated")")
                    .bold()
                    .foregroundColor(.purple)

                Text("Active Theme Mode: \(viewModel.currentTheme)")
                Text("Pass Active: \(viewModel.isBoardingPassActive)")
                    .foregroundColor(viewModel.isBoardingPassActive ? .green : .red)
            }
            .padding()
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.gray.opacity(0.1))
            .cornerRadius(8)

            // --- OVERLOADED OPERATOR ARRAY DISPLAY SECTION ---
            VStack(alignment: .leading, spacing: 2) {
                Text("Master Itinerary Sequence (Combined via '+' Operator):")
                    .font(.caption)
                    .bold()
                Text("\(viewModel.gateStops)")
                    .font(.caption2)
                    .foregroundColor(.indigo)
            }
            .frame(maxWidth: .infinity, alignment: .leading)

            // --- SET DISPLAY SECTION ---
            VStack(alignment: .leading, spacing: 2) {
                Text("Unique Loyalty Perks (Set):")
                    .font(.caption)
                    .bold()
                Text("\(viewModel.loyaltyPerks)")
                    .font(.caption2)
                    .foregroundColor(.purple)
            }
            .frame(maxWidth: .infinity, alignment: .leading)

            // --- INTERACTIVE BUTTON SECTION ---
            Button(action: {
                viewModel.performCheckIn()
            }) {
                Text("Check-In & Evaluate Conditions")
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
        }
        .padding()
    }
}
