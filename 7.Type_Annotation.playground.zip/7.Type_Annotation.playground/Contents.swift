import Cocoa
import Foundation


/*
 Now let's dive into Type Annotations, which you can also follow along with on the Type annotations page!

 By default, Swift uses something called Type Inference. This means Swift is smart enough to look at the value you give a variable or constant and figure out its type automatically (like knowing "Hello" is a String).

 However, if you want to be explicit—or if you want to create an empty variable to fill in later—you can use a type annotation by adding a colon (:) followed by the type name right after your variable or constant name.

 Examples of Type Annotations
 */
// Explicitly stating the data types using a colon
let album: String = "Reputation"
let year: Int = 1989
let height: Double = 1.78
let taylorRocks: Bool = true

/*
 Why Use Type Annotations?
 Clarity: It makes your intentions crystal clear to other developers reading your code.

 Creating Empty Variables: Sometimes you need to declare a variable before you actually have its final value. Type inference won't work here because Swift doesn't know what kind of data is coming, so an annotation is required:
 */
var guessedNumber: Int
// Later in your code...
guessedNumber = 42

// 1. Explicit Type Annotations (stating the type using a colon)
let username: String = "CaptainCoder"
let loginAttempts: Int = 3
let storageQuota: Double = 50.8
let isOnline: Bool = true

// 2. Type Inference (Swift automatically figures out the type without an annotation)
let defaultTheme = "Dark Mode" // Swift infers this is a String

// 3. Using the variables together
print("User: \(username)")
print("Attempts: \(loginAttempts)")
print("Storage used: \(storageQuota) GB")
print("Online status: \(isOnline)")
print("Theme: \(defaultTheme)")
