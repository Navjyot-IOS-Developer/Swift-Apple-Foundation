import Foundation
import SwiftUI

/*
 What are Comparison Operators?
 Just like in mathematics, Swift uses comparison operators to compare two values against each other. They always evaluate to a Boolean result: either true or false.

 Let's start with a couple of example variables from your tutorial:

  Greater Than and Less Than
 These work just like math class:

 > (Greater Than): firstScore > secondScore (true)

 < (Less Than): firstScore < secondScore (false)

 >= (Greater Than or Equal To): firstScore >= secondScore (true)

 <= (Less Than or Equal To): firstScore <= secondScore (false)

Comparing Strings
 Comparison operators also work with strings because Swift evaluates them using a natural alphabetical order:

 */

let alphabeticalCheck = "Taylor" <= "Swift"
// Evaluates to true because "Taylor" comes before "Swift" alphabetically!
