import Foundation
import SwiftUI

/*
 What is a Tuple?
 Like an array, a Tuple lets you store several values together in a single variable. However, tuples have three strict rules that make them completely different:

 Fixed Size: You cannot add or remove items from a tuple after it is created.

 Fixed Types: You cannot change the types of items inside a tuple. The types are locked in the moment it is created.

 Flexible Access: You can access items using numerical positions (starting at 0), or by giving the elements names!

 */
// Creating a tuple with named elements
var name = (first: "Taylor", last: "Swift")

// Accessing items using numerical positions (like arrays)
print(name.0) // Output: Taylor

// Accessing items using their explicit names (much cleaner!)
print(name.first) // Output: Taylor

/*
 2. The Strict Type Rule
 You can change the values inside a tuple as long as they match the original data types, but you cannot change their types. For example:
 */

// ✅ Allowed: Changing the value because it's still a String
name = (first: "Justin", last: "Timberlake")

// ❌ Error! Swift won't let you change 'last' to an Integer (like an age),
// because it was originally created as a String type.
// name = (first: "Justin", age: 25)

/*
 3. Real-World iOS Example: HTTP Network Responses
 In real iOS app development, tuples are frequently used when a function needs to return multiple distinct pieces of data at once—such as returning both a server response code and a success status message from a network request:
 */


// A function returning a tuple containing an Integer status code and a Boolean flag
func fetchUserData() -> (statusCode: Int, isSuccessful: Bool) {
    return (statusCode: 200, isSuccessful: true)
}

// Capturing the tuple result
let serverResponse = fetchUserData()

print("Status Code: \(serverResponse.statusCode)")
print("Success: \(serverResponse.isSuccessful)")

/*
 Good morning! Let's build a real-world iOS app example that brings together everything we've learned so far: Variables, Constants, Types (Strings, Integers, Doubles, Booleans), Arrays, Sets, and Tuples.

 Imagine building a Flight Booking & Trip Management App (like an airline dashboard).

 Here is how an iOS developer structures this across two clean cells—separating the Backend Logic from the UI Screen:

 Cell 1: The Backend Swift Logic & Data State
 This handles all our data storage rules, tracking passenger details, booking options, and immutable flight information.
 */

// ==========================================
// BACKEND SWIFT LOGIC & DATA STATE
// ==========================================

import Foundation

class FlightBookingViewModel {
    // 1. Constants (Fixed flight rules and configuration)
    let airlineName: String = "SwiftAir Global"
    let flightNumber: String = "SW-2026"

    // 2. Variables & Primitive Types (Dynamic app state)
    var passengerName: String = "Navjot"
    var seatNumber: Int = 14
    var ticketPrice: Double = 299.99
    var isBoardingPassActive: Bool = true

    // 3. Arrays (Ordered lists, like sequential boarding gate stops)
    var gateStops: [String] = ["Security Check", "Customs", "Gate B4"]

    // 4. Sets (Unordered collections that guarantee unique frequent flyer perks)
    var loyaltyPerks: Set<String> = Set(["Lounge Access", "Priority Boarding", "Extra Baggage", "Lounge Access"])

    // 5. Tuples (Fixed grouping of multiple values returned together, like flight status info)
    var flightStatus: (statusMessage: String, gateDelayMinutes: Int) = (statusMessage: "On Time", gateDelayMinutes: 0)

    // Action function simulating user interaction
    func updateBoardingStatus() {
        isBoardingPassActive.toggle()
        gateStops.append("Boarding Aircraft")
    }
}

/*
 Cell 2: The Actual UI Screen Code (SwiftUI)
 This represents the visual iOS app screen that binds to our backend model, presenting the data dynamically using String Interpolation.
 */

// ==========================================
// ACTUAL UI SCREEN CODE (SwiftUI)
// ==========================================

import SwiftUI

struct FlightPassView: View {
    // Connects our backend view model logic to the UI
    @State private var viewModel = FlightBookingViewModel()

    var body: some View {
        VStack(spacing: 16) {

            // Header using Constants & String Interpolation
            Text("Welcome to \(viewModel.airlineName)")
                .font(.title2)
                .bold()

            // Flight Number & Status Tuple
            HStack {
                Text("Flight: \(viewModel.flightNumber)")
                Spacer()
                Text("Status: \(viewModel.flightStatus.statusMessage)")
                    .foregroundColor(.green)
                    .bold()
            }
            .padding(.horizontal)

            // Passenger & Seat Details (Strings, Integers, Booleans)
            VStack(alignment: .leading, spacing: 6) {
                Text("Passenger: \(viewModel.passengerName)")
                Text("Assigned Seat: Row \(viewModel.seatNumber)")
                Text("Ticket Price: $\(viewModel.ticketPrice)")
                Text("Pass Active: \(viewModel.isBoardingPassActive)")
                    .foregroundColor(viewModel.isBoardingPassActive ? .blue : .red)
            }
            .padding()
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.gray.opacity(0.1))
            .cornerRadius(10)

            // Displaying Array Data (Gate Sequence)
            VStack(alignment: .leading, spacing: 4) {
                Text("Gate Sequence (Array):")
                    .font(.caption)
                    .bold()
                Text("\(viewModel.gateStops)")
                    .font(.caption2)
            }
            .frame(maxWidth: .infinity, alignment: .leading)

            // Displaying Set Data (Unique Loyalty Perks - duplicates filtered out)
            VStack(alignment: .leading, spacing: 4) {
                Text("Unique Loyalty Perks (Set):")
                    .font(.caption)
                    .bold()
                Text("\(viewModel.loyaltyPerks)")
                    .font(.caption2)
                    .foregroundColor(.purple)
            }
            .frame(maxWidth: .infinity, alignment: .leading)

            // Interactive UI Button
            Button(action: {
                // Triggers backend logic updates when tapped by the user
                viewModel.updateBoardingStatus()
            }) {
                Text("Check-In / Proceed to Gate")
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
        }
        .padding()
    }
}
