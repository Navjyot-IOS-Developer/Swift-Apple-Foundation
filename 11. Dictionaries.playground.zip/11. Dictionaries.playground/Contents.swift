import Foundation
import SwiftUI

/*
 What is a Dictionary?
 Just like arrays, Dictionaries are collections of values stored together. However, instead of accessing items using a numerical position (like an index 0 or 1), you access them using a key of your own choosing (usually a String).

 Think of it like a real-world dictionary: you look up a word (the key, e.g., "Taylor Swift") to find its definition or value (the value, e.g., 1.78).

 1. Creating and Using Dictionaries
 Here is how you create a dictionary in Swift:

 */
// 1. Creating a dictionary with String keys and Double values
let heights = [
    "Taylor Swift": 1.78,
    "Ed Sheeran": 1.73
]

// 2. Reading data back out using the key
print(heights["Taylor Swift"])
// Output: Optional(1.78)

// =====================================================================
// BACKEND SWIFT LOGIC & STATE (Flight Dashboard App)
// =====================================================================

import Foundation

class FlightDashboardViewModel {

    // 1. CONSTANTS (let): Fixed application rules and static metadata
    let airlineName: String = "SwiftAir Global"
    let flightNumber: String = "SW-2026"

    // 2. VARIABLES & PRIMITIVE TYPES (var): Dynamic state that updates based on user actions
    var passengerName: String = "Navjot"
    var seatNumber: Int = 14
    var ticketPrice: Double = 299.99
    var isBoardingPassActive: Bool = true

    // 3. ARRAYS ([String]): Ordered lists that preserve sequential steps (e.g., security check points)
    var gateStops: [String] = ["Security Check", "Customs", "Gate B4"]

    // 4. SETS (Set<String>): Unordered collections that automatically filter out duplicate entries
    var loyaltyPerks: Set<String> = Set(["Lounge Access", "Priority Boarding", "Extra Baggage", "Lounge Access"])

    // 5. TUPLES ((String, Int)): Fixed-size, fixed-type groupings for tightly coupled return values
    var flightStatus: (statusMessage: String, gateDelayMinutes: Int) = (statusMessage: "On Time", gateDelayMinutes: 0)

    // 6. DICTIONARIES ([String: String]): Key-value pairs for fast keyword lookups (e.g., metadata or preference configs)
    var seatPreferences: [String: String] = [
        "mealType": "Vegetarian",
        "seatingPreference": "Window",
        "baggageSize": "Carry-On Only"
    ]

    // 7. BACKEND FUNCTION: Handles UI interactions and mutates state
    func updateDashboard() {
        // Toggles boolean pass state
        isBoardingPassActive.toggle()

        // Appends to our sequential array
        gateStops.append("Boarding Aircraft")

        // Updates a dictionary value dynamically
        seatPreferences["mealType"] = "Vegan"
    }
}

// =====================================================================
// ACTUAL UI SCREEN CODE (SwiftUI Interface)
// =====================================================================

import SwiftUI

struct FlightDashboardView: View {

    // Connects our backend view model logic to this SwiftUI screen
    @State private var viewModel = FlightDashboardViewModel()

    var body: some View {
        VStack(spacing: 14) {

            // --- HEADER SECTION ---
            // Displays static brand data using constants and string interpolation
            Text("Welcome to \(viewModel.airlineName)")
                .font(.title2)
                .bold()

            // --- TUPLE DISPLAY SECTION ---
            // Accesses nested tuple elements via dot notation
            HStack {
                Text("Flight: \(viewModel.flightNumber)")
                Spacer()
                Text("Status: \(viewModel.flightStatus.statusMessage)")
                    .foregroundColor(.green)
                    .bold()
            }
            .padding(.horizontal)

            // --- PASSENGER & PRIMITIVE TYPES SECTION ---
            // Displays strings, integers, doubles, and booleans
            VStack(alignment: .leading, spacing: 4) {
                Text("Passenger: \(viewModel.passengerName)")
                Text("Seat: Row \(viewModel.seatNumber)")
                Text("Price: $\(viewModel.ticketPrice)")
                Text("Pass Active: \(viewModel.isBoardingPassActive)")
                    .foregroundColor(viewModel.isBoardingPassActive ? .blue : .red)
            }
            .padding()
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.gray.opacity(0.1))
            .cornerRadius(8)

            // --- ARRAY DISPLAY SECTION ---
            // Displays our sequential gate stops array
            VStack(alignment: .leading, spacing: 2) {
                Text("Gate Sequence (Array):")
                    .font(.caption)
                    .bold()
                Text("\(viewModel.gateStops)")
                    .font(.caption2)
            }
            .frame(maxWidth: .infinity, alignment: .leading)

            // --- SET DISPLAY SECTION ---
            // Displays unique loyalty perks where duplicates were automatically ignored
            VStack(alignment: .leading, spacing: 2) {
                Text("Unique Loyalty Perks (Set):")
                    .font(.caption)
                    .bold()
                Text("\(viewModel.loyaltyPerks)")
                    .font(.caption2)
                    .foregroundColor(.purple)
            }
            .frame(maxWidth: .infinity, alignment: .leading)

            // --- DICTIONARY DISPLAY SECTION ---
            // Displays key-value user preferences lookup dictionary
            VStack(alignment: .leading, spacing: 2) {
                Text("Passenger Preferences (Dictionary):")
                    .font(.caption)
                    .bold()
                Text("Meal: \(viewModel.seatPreferences["mealType"] ?? "Standard") | Spot: \(viewModel.seatPreferences["seatingPreference"] ?? "Any")")
                    .font(.caption2)
                    .foregroundColor(.orange)
            }
            .frame(maxWidth: .infinity, alignment: .leading)

            // --- INTERACTIVE BUTTON SECTION ---
            // Tapping this triggers the backend function, instantly updating state and UI elements
            Button(action: {
                viewModel.updateDashboard()
            }) {
                Text("Check-In & Update Preferences")
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
        }
        .padding()
    }
}
