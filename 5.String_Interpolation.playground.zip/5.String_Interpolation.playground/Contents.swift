import Foundation

/*
 Now let's look at String Interpolation—one of the handiest features in Swift!

 As you can see on the String interpolation page, string interpolation allows you to embed variables and even small pieces of code directly inside a string. Instead of trying to add (+) numbers and text together manually, Swift lets you drop your variables right into the text using a backslash and parentheses: \(variableName).

 Here is a simple example in action:

 */

// 1. Create a variable
var score = 85

// 2. Interpolate the variable inside a string
var message = "Your score was \(score)"

print(message)
// Output: Your score was 85

// 3. You can even use strings inside other strings!
var announcement = "Attention everyone: \(message)!"

print(announcement)
// Output: Attention everyone: Your score was 85!

/*

 Why it's useful:
 Clean Code: It saves you from complex string concatenation (like print("Score: " + String(score))).

 Any Type Works: You aren't limited to integers; you can interpolate Doubles, Booleans, or even other Strings inside your templates.

 */
