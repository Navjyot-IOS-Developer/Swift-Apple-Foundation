import Foundation
import SwiftUI

/*
 Here is a short, clean example showing Dictionary Default Values in a single code cell, picking up right from your Dictionary default values page:
 Why it's useful:
 Instead of dealing with optional nil values when a key isn't found in your dictionary, providing a default value guarantees your app always gets a valid fallback string or number instantly!

 Its use Unknown there simply.
 */

// 1. Create a dictionary with initial key-value pairs
let favoriteIceCream = [
    "Paul": "Chocolate",
    "Sophie": "Vanilla"
]

// 2. Reading an existing key works normally
let paulsFavorite = favoriteIceCream["Paul"]
print(paulsFavorite!) // Output: Optional("Chocolate")

// 3. Reading a missing key (like "Charlotte") normally returns nil
// But by using a default value, Swift safely returns "Unknown" instead of nil!
let charlottesFavorite = favoriteIceCream["Charlotte", default: "Unknown"]

print(charlotteFavorite)
// Output: Unknown
