import Foundation

/*
 Good evening! Let's talk about Constants, the counterpart to variables that you can explore further on the Constants tutorial page.

 While variables (var) are designed to change over time, constants (let) are used when you want to set a value once and ensure it never changes.

 Here is how constants work in Swift:

 */

// 1. Create a constant using the "let" keyword
let swiftAuthor = "Paul Hudson"

// 2. You can read and use constants just like variables
print(swiftAuthor) // Output: Paul Hudson

// 3. If you try to change it later, Xcode will refuse to run your code!
// swiftAuthor = "Someone Else" // ❌ Error! Cannot assign to value: 'swiftAuthor' is a 'let' constant

/*
 Why Use Constants?
 Safety: It prevents bugs by ensuring critical data (like API keys, configuration settings, or fixed IDs) doesn't get accidentally overwritten somewhere else in your code.

 Best Practice in Swift: In Swift, you should always use let by default unless you specifically know the value needs to change later. Xcode will actually warn you if you use var for something that never changes!

 */
